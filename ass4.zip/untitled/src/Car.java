public class Car implements Vehicle {
    @Override
    public void start() {
        System.out.println("Starting the car.");
        checkFuel();
        fastenSeatbelts();
        igniteEngine();
    }

    @Override
    public void stop() {
        System.out.println("Stopping the car.");
        applyBrakes();
        turnOffEngine();
    }


    private void checkFuel() {
        System.out.println("Checking fuel level.");
    }

    private void fastenSeatbelts() {
        System.out.println("Fastening seatbelts.");

    }

    private void igniteEngine() {
        System.out.println("Igniting the engine.");

    }

    private void applyBrakes() {
        System.out.println("Applying brakes.");

    }

    private void turnOffEngine() {
        System.out.println("Turning off the engine.");
    }
}