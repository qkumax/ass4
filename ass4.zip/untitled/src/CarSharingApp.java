public class CarSharingApp {
    public static void main(String[] args) {
        VehicleFactory factory = new VehicleFactory();
        Vehicle car = factory.createVehicle("Car");
        Vehicle bike = factory.createVehicle("Bike");
        Vehicle scooter = factory.createVehicle("Scooter");

        car.start();
        bike.start();
        scooter.start();
        car.stop();
        bike.stop();
        scooter.stop();
    }
}

