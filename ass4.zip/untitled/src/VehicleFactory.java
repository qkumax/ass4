public class VehicleFactory {
    public Vehicle createVehicle(String type) {
        if ("Car".equals(type)) {
            return new Car();
        } else if ("Bike".equals(type)) {
            return new Bike();
        } else if ("Scooter".equals(type)) {
            return new Scooter();
        } else {
            throw new IllegalArgumentException("Invalid vehicle type");
        }
    }
}

